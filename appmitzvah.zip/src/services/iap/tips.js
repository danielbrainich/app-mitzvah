import * as RNIap from "react-native-iap";

export const TIP_PRODUCT_IDS = [
    "appmitzvah.tip.c1",
    "appmitzvah.tip.c2",
    "appmitzvah.tip.c3",
    "appmitzvah.tip.c4",
    "appmitzvah.tip.c5",
];

export async function initIap() {
    try {
        await RNIap.initConnection();
    } catch (err) {
        console.error("Failed to initialize IAP connection:", err);
        throw err;
    }
}

export async function endIap() {
    try {
        await RNIap.endConnection();
    } catch (err) {
        console.debug("Error ending IAP connection:", err);
    }
}

const amountFromId = (id) => {
    if (!id || typeof id !== "string") return 0;
    const parts = id.split("_");
    const n = Number(parts[parts.length - 1]);
    return Number.isFinite(n) && n > 0 ? n : 0;
};

export async function fetchTipProducts() {
    try {
        const products = await RNIap.getProducts({ skus: TIP_PRODUCT_IDS });

        if (!Array.isArray(products)) {
            console.error("Invalid products response:", products);
            return [];
        }

        return products
            .filter((p) => p && p.productId)
            .sort(
                (a, b) => amountFromId(a.productId) - amountFromId(b.productId)
            );
    } catch (err) {
        console.error("Failed to fetch tip products:", err);
        throw err;
    }
}

export async function buyTip(amount) {
    if (!amount || typeof amount !== "number" || amount <= 0) {
        throw new Error("Invalid tip amount");
    }

    const productId = `appmitzvah.tip.c${amount}`;

    if (!TIP_PRODUCT_IDS.includes(productId)) {
        throw new Error(`Invalid product ID: ${productId}`);
    }

    try {
        const purchase = await RNIap.requestPurchase({ sku: productId });
        const p = Array.isArray(purchase) ? purchase[0] : purchase;

        if (!p) {
            throw new Error("Purchase returned empty result");
        }

        await RNIap.finishTransaction({ purchase: p, isConsumable: true });

        return p;
    } catch (err) {
        console.error("Purchase failed:", err);

        if (err.message && err.message.includes("finish")) {
            console.warn("Attempting to finish orphaned transaction");
        }

        throw err;
    }
}
